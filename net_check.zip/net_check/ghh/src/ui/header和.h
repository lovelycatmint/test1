#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QTableWidget>
#include <ros/ros.h>
#include <std_msgs/String.h>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(int argc, char **argv, QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void doMsg(const std_msgs::String::ConstPtr& msg_p);

private:
    Ui::MainWindow *ui;
    ros::Subscriber sub;
    int hz;
    timeval T1, T2;
    int discard;
    int count_temp;
    std::vector<int> count;
    std::vector<std::string> timeout;
    QtCharts::QChartView *chartView;
    QtCharts::QLineSeries *series;
    QTableWidget *tableWidget;
    void displayData(const std::string& time, const std::string& interval, const std::string& status);
};
