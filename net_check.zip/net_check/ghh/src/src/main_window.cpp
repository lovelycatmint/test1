#include "ui_mainwindow.h"
#include <sys/time.h>
#include <iostream>
#include <chrono>
#include <ctime>
#include <string>
#include <vector>
#include <QTableWidgetItem>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

MainWindow::MainWindow(int argc, char **argv, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , discard(0)
    , count_temp(0)
{
    ui->setupUi(this);

    ros::init(argc, argv, "qt_ros_node");
    if (!ros::master::check()) {
        ROS_ERROR("Unable to communicate with master!");
        exit(-1);
    }
    ros::NodeHandle nh;

    if (argc < 4) {
        ROS_ERROR("Insufficient arguments provided. Usage: rosrun <package_name> <executable_name> <topic_name> <rate>");
        exit(-1);
    }

    hz = 1000 / std::stoi(argv[3]);
    sub = nh.subscribe<std_msgs::String>(argv[2], 10, &MainWindow::doMsg, this);

    // 创建波线图
    chartView = new QtCharts::QChartView(new QtCharts::QChart());
    series = new QtCharts::QLineSeries();
    chartView->chart()->addSeries(series);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui->verticalLayout->addWidget(chartView);

    // 创建统计表
    tableWidget = new QTableWidget();
    tableWidget->setColumnCount(3);
    QStringList headers;
    headers << "Time" << "Interval" << "Status";
    tableWidget->setHorizontalHeaderLabels(headers);
    ui->verticalLayout->addWidget(tableWidget);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::doMsg(const std_msgs::String::ConstPtr& msg_p)
{
    // 实现消息处理逻辑，更新波线图和统计表
}

void MainWindow::displayData(const std::string& time, const std::string& interval, const std::string& status)
{
    int row = tableWidget->rowCount();
    tableWidget->insertRow(row);

    tableWidget->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(time)));
    tableWidget->setItem(row, 1, new QTableWidgetItem(QString::fromStdString(interval)));
    tableWidget->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(status)));

    // 更新波线图
}
